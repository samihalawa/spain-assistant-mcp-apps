# Condiciones — Ayudas España

Las instrucciones originales se distribuyen bajo la licencia MIT del repositorio. Esa licencia no concede derechos sobre publicaciones oficiales, bases de datos, marcas ni documentos de terceros. Consulta las condiciones de cada fuente para su reutilización.

La edición 0.6.0 combina una consulta pública de solo lectura mediante un conector MCP alojado e instrucciones de lectura y redacción con las funciones autorizadas del anfitrión y documentos aportados. No es un servicio oficial, certificación, representación profesional ni garantía de resultado. Las fuentes pueden cambiar, faltar o contener errores; el asistente debe conservar fechas, origen y límites.

Las bases, modificaciones y sede oficial determinan el acceso. Los plazos y señales del buscador no acreditan elegibilidad ni estado actual. No presenta solicitudes ni garantiza financiación.

El usuario y el anfitrión controlan la navegación, el tratamiento de documentos y la conservación de respuestas. No se debe usar esta habilidad para acceder a información protegida, revelar secretos ni ejecutar trámites o seguimiento no autorizados. Los ejemplos guardados son históricos y no sustituyen una comprobación actual.

No hay relación ni respaldo de las autoridades públicas citadas. La disponibilidad de estas instrucciones no implica admisión en ningún directorio o compatibilidad verificada con todos los anfitriones.
