# Soporte — BORME Intelligence

Contacto: sami@samihalawa.com · https://github.com/samihalawa/borme-intelligence/issues

Indica versión 0.6.2, anfitrión, herramienta `review_spanish_company_events`, fecha, identificador o filtro público mínimo y resultado esperado. Distingue fallo de conexión, error de la fuente, cobertura parcial y problema de interpretación. No envíes credenciales, conversaciones completas ni documentos privados.

El servicio consulta fuentes públicas y no tramita solicitudes ni proporciona certificaciones. Un error no significa ausencia de registros. Los ejemplos guardados son históricos.
