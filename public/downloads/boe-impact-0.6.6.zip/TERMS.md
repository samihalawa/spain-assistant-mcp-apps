# Condiciones — Spain Laws & BOE

Las instrucciones originales se distribuyen bajo la licencia MIT del repositorio. Esa licencia no concede derechos sobre publicaciones oficiales, bases de datos, marcas ni documentos de terceros. Consulta las condiciones de cada fuente para su reutilización.

La edición 0.6.6 combina una consulta pública de solo lectura mediante un conector MCP alojado e instrucciones de lectura y redacción con las funciones autorizadas del anfitrión y documentos aportados. No es un servicio oficial, certificación, representación profesional ni garantía de resultado. Las fuentes pueden cambiar, faltar o contener errores; el asistente debe conservar fechas, origen y límites.

La consolidación es informativa. La habilidad no determina automáticamente aplicabilidad, régimen transitorio o conformidad legal. Verifica las publicaciones originales para decisiones jurídicas.

El usuario y el anfitrión controlan la navegación, el tratamiento de documentos y la conservación de respuestas. No se debe usar esta habilidad para acceder a información protegida, revelar secretos ni ejecutar trámites o seguimiento no autorizados. Los ejemplos guardados son históricos y no sustituyen una comprobación actual.

No hay relación ni respaldo de las autoridades públicas citadas. La disponibilidad de estas instrucciones no implica admisión en ningún directorio o compatibilidad verificada con todos los anfitriones.
